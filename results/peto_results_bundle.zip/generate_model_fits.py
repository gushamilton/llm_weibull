import os
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

DATA_FILE = "/Users/fh6520/R/peto/eval-analysis-public/data/external/all_runs.jsonl"
OUTPUT_DIR = "/Users/fh6520/R/peto/results"
PLOTS_DIR = os.path.join(OUTPUT_DIR, "model_fits")

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(PLOTS_DIR, exist_ok=True)

if not os.path.exists(DATA_FILE):
    raise FileNotFoundError(DATA_FILE)

# Models

def logistic_model(t, b0, b1):
    return 1 / (1 + np.exp(-(b0 + b1 * np.log(t))))

def exponential_model(t, lam):
    return np.exp(-lam * t)

def weibull_model(t, lam, k):
    return np.exp(-(lam * t) ** k)

# Log-likelihood (Bernoulli)

def loglik(p, y):
    eps = 1e-12
    p = np.clip(p, eps, 1 - eps)
    return np.sum(y * np.log(p) + (1 - y) * np.log(1 - p))

# BIC

def bic(ll, k, n):
    return k * np.log(n) - 2 * ll

# Load data

df = pd.read_json(DATA_FILE, lines=True)
if "alias" not in df.columns:
    raise KeyError("Expected column 'alias' not found in dataset.")

required_cols = ["human_minutes", "score_binarized"]

aliases = pd.Series(df["alias"].dropna().unique()).sort_values().tolist()
skip_aliases = {"gpt-3.5-turbo-instruct"}

rows = []

for alias in aliases:
    if alias in skip_aliases:
        continue
    subset = df[df["alias"] == alias].copy()
    if any(c not in subset.columns for c in required_cols):
        continue
    subset = subset[required_cols].dropna()
    subset = subset[subset["human_minutes"] > 0]
    if len(subset) < 50:
        continue

    t_data = subset["human_minutes"].values
    y_data = subset["score_binarized"].values

    # Fit models
    try:
        popt_log, _ = curve_fit(logistic_model, t_data, y_data, p0=[2.0, -0.5], maxfev=20000)
    except Exception:
        popt_log = [np.nan, np.nan]

    try:
        popt_exp, _ = curve_fit(exponential_model, t_data, y_data, p0=[0.005], bounds=(0, np.inf), maxfev=20000)
    except Exception:
        popt_exp = [np.nan]

    try:
        popt_weib, _ = curve_fit(weibull_model, t_data, y_data, p0=[0.005, 1.0], bounds=(0, np.inf), maxfev=20000)
    except Exception:
        popt_weib = [np.nan, np.nan]

    # Likelihoods
    p_log = logistic_model(t_data, *popt_log) if np.all(np.isfinite(popt_log)) else np.full_like(y_data, np.nan, dtype=float)
    p_exp = exponential_model(t_data, *popt_exp) if np.all(np.isfinite(popt_exp)) else np.full_like(y_data, np.nan, dtype=float)
    p_weib = weibull_model(t_data, *popt_weib) if np.all(np.isfinite(popt_weib)) else np.full_like(y_data, np.nan, dtype=float)

    ll_log = loglik(p_log, y_data) if np.all(np.isfinite(p_log)) else np.nan
    ll_exp = loglik(p_exp, y_data) if np.all(np.isfinite(p_exp)) else np.nan
    ll_weib = loglik(p_weib, y_data) if np.all(np.isfinite(p_weib)) else np.nan

    n = len(y_data)

    bic_log = bic(ll_log, 2, n) if np.isfinite(ll_log) else np.nan
    bic_exp = bic(ll_exp, 1, n) if np.isfinite(ll_exp) else np.nan
    bic_weib = bic(ll_weib, 2, n) if np.isfinite(ll_weib) else np.nan

    bics = {
        "logistic": bic_log,
        "exponential": bic_exp,
        "weibull": bic_weib,
    }
    best_bic = min(bics.items(), key=lambda kv: kv[1] if np.isfinite(kv[1]) else np.inf)[0]

    rows.append(
        {
            "alias": alias,
            "n": n,
            "logistic_b0": popt_log[0],
            "logistic_b1": popt_log[1],
            "exponential_lambda": popt_exp[0],
            "weibull_lambda": popt_weib[0],
            "weibull_k": popt_weib[1],
            "bic_logistic": bic_log,
            "bic_exponential": bic_exp,
            "bic_weibull": bic_weib,
            "best_bic": best_bic,
        }
    )

    # Empirical bins for plotting
    bins = subset.groupby("human_minutes")["score_binarized"].agg(["mean", "count"]).reset_index()
    bins = bins[bins["count"] > 2]

    x_min = float(np.min(t_data))
    x_max = float(np.max(t_data))
    x_range = np.logspace(np.log10(x_min), np.log10(x_max), 200)

    plt.figure(figsize=(10, 6))
    if len(bins) > 0:
        plt.scatter(
            bins["human_minutes"],
            bins["mean"],
            color="black",
            alpha=0.6,
            s=bins["count"] * 2,
            label="Empirical (size=count)",
        )

    if np.all(np.isfinite(popt_log)):
        plt.plot(x_range, logistic_model(x_range, *popt_log), "b--", linewidth=2, label="Logistic")
    if np.all(np.isfinite(popt_exp)):
        plt.plot(x_range, exponential_model(x_range, *popt_exp), "orange", linewidth=2, label="Constant hazard")
    if np.all(np.isfinite(popt_weib)):
        plt.plot(x_range, weibull_model(x_range, *popt_weib), "r-", linewidth=3, label=f"Weibull k={popt_weib[1]:.2f}")

    plt.xscale("log")
    plt.ylim(-0.05, 1.05)
    plt.xlabel("Task Difficulty (Human Minutes) [Log Scale]")
    plt.ylabel("Probability of Success")
    plt.title(f"{alias} | Best BIC: {best_bic}")
    plt.legend()
    plt.grid(True, which="both", alpha=0.3)
    plt.tight_layout()

    safe_alias = "".join(ch if ch.isalnum() else "_" for ch in alias).lower()
    plot_path = os.path.join(PLOTS_DIR, f"{safe_alias}.png")
    plt.savefig(plot_path)
    plt.close()

summary = pd.DataFrame(rows).sort_values(by="alias")
summary_path = os.path.join(OUTPUT_DIR, "model_fit_summary.csv")
summary.to_csv(summary_path, index=False)

print(f"Saved summary: {summary_path}")
print(f"Saved plots: {PLOTS_DIR}")
